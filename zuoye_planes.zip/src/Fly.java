
public interface Fly{
	public void SubSonicFly();
	public void SuperSonicFly();
}
