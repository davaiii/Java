
public abstract class Fighter implements Fly, TakeOff {
	public void LongDistanceTakeOff() {}
	public void SuperSonicFly() {}
}
