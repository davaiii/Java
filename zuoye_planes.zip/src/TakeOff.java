
public interface TakeOff {
	public void VerticalTakeOff();
	public void LongDistanceTakeOff();
}
