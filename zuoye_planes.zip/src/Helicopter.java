
public abstract class Helicopter implements Fly, TakeOff {
	public void VerticalTakeOff() {}
	public void SubSonicFly() {}
}
