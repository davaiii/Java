
public abstract class AirPlane implements Fly, TakeOff {
	public void LongDistanceTakeOff() {}
	public void SubSonicFly() {}
}
