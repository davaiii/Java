
public abstract class Harrier implements Fly, TakeOff {
	public void VerticalTakeOff() {}
	public void SuperSonicFly() {}
}
